<?php
Class HessianA{

public $db;
 function connect(){
 	$sdb_name="localhost"; //������
	$db_name="hfdl_airdata"; //�������� ���� ������
	$user_name="hfdl"; //��� ������������
	$db_password="andromeda"; //������
	$db = mysql_connect($sdb_name, $user_name, $db_password);
    $dbm = mysql_select_db($db_name);
 }
 function insert($result){
 $this->connect();
	$fly_id =$result[1];
	$field_a=$result[2];
	$field_b=$result[3];
    $tm_bort=$result[4];
	$coord=$result[5].".".$result[6].$result[7].$result[8]." ".$result[9].".".$result[10].$result[11].$result[12];
    $user_id=$result[13];
	$del="DELETE  FROM `hfdl_data` WHERE `get_datetime`<NOW()-INTERVAL 10 HOUR";
	$deldouble="DELETE  FROM `hfdl_data` WHERE `fly_id`="+$fly_id+" AND `tm_bort`="+$tm_bort+" AND `coord`="+$coord;
	$str_sql_query = "INSERT INTO `hfdl_data` (`fly_id` ,`tm_bort` ,`coord` ,`user_id` ,`field_a` ,`field_b`, `get_datetime`)".
	"VALUES ('$fly_id', '$tm_bort', '$coord', '$user_id', '$field_a', '$field_b',NOW())";

	mysql_query($del);
	mysql_query($deldouble);	
	mysql_query($str_sql_query);  
 }
function select(){
 $this->connect();
	$result = mysql_query("SELECT fly_id, tm_bort, coord, user_id, field_a, field_b FROM `hfdl_data` WHERE  `get_datetime`>NOW()-INTERVAL 10 HOUR ORDER BY `get_datetime` DESC;");
	while($row=mysql_fetch_array($result, MYSQL_NUM))
	{
	$data[] = $row;
	 
	}
	return $data;
 }
}

include_once 'hes/HessianService.php';
$wrapper = &new HessianService();
$wrapper->registerObject(new HessianA);
$wrapper->service();
?>