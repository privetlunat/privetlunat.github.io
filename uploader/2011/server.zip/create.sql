CREATE TABLE `hfdl_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fly_id` varchar(10) NOT NULL DEFAULT '',
  `tm_bort` varchar(100) NOT NULL DEFAULT '',
  `coord` varchar(40) NOT NULL DEFAULT '',
  `user_id` varchar(30) NOT NULL DEFAULT '',
  `field_a` varchar(200) DEFAULT '',
  `field_b` varchar(200) DEFAULT '',
  `get_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8; 