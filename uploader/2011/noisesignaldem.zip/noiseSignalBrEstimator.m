function noiseSignalBrEstimator(fileName, C)
% fileName = noise-signal (WAVE file), here: 'noiseTelegram.wav'
% C - delaly in samples read from ACF graph (SA, noiseSignalAcfEstimator.m, other)
%
clc;
close all;
%
[y,fs,bitsPerSample] = wavread(fileName);
y=y(:);
y=y';
%
figure()
t=0:1/fs:(length(y)-1)*(1/fs);
plot(t,y(1,1:floor(length(y))))
title('Noise-signal')
xlabel('Time [s]');
grid on
set(gcf, 'color', 'white');
%
%
% =================  Autocorrelation receiver (by Petrovich)
r = zeros(1,length(y));
for i=1:length(y),
    if i > C
        r(i) = y(i)*y(i - C);
    end
end
%
% writting into WAVE to check Br estimate using SA
wavwrite(r(C+1:end),fs,16,'sequence_r[n].wav');
%
%
% transforming into "analytic" signal
u = hilbert(r(C+1:end));
%
% instant amplitude of band-pass real signal
a = (abs(u));
%
nfft=16384;
%w = window(@blackmanharris,nfft);
wind = window(@hamming,nfft);
%
[psda,f1] = periodogram(a,[],[],fs);
psda=psda/max(abs(psda));
%
[Pxx1,f2] = pwelch(r,wind,nfft/2,nfft,fs);
Pxx1=Pxx1/max(abs(Pxx1));
%
figure()
subplot(2,1,1)
plot(f2,10*log10(Pxx1),'b')
title([{'Normalized Welch Power Spectral Density of r[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
os_x=[0:20:500];
set(gca,'xtick',os_x,'xgrid','on');
xlim([0 500]);
grid on
%
subplot(2,1,2)
plot(f1,10*log10(psda))
title([{'Normalized Periodogram of Instantaneous Amplitude of r[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
ylim([-60 0])
grid on
set(gcf, 'color', 'white')
%
%