function noiseSignalDemodulator(fileName, C, Br)
% fileName = noise-signal (WAVE file), here: 'noiseTelegram.wav'
% C - delaly in samples read from ACF graph (SA, noiseSignalAcfEstimator.m,
% other)
% Br - baud rate read from Normalized Periodogram of Instantaneous
% Amplitude of r[n] (or from double half-wave detector of SA)
%
clc;
close all;
%
[y,fs,bitsPerSample] = wavread(fileName);
y=y(:);
y=y';
%
figure()
t=0:1/fs:(length(y)-1)*(1/fs);
plot(t,y(1,1:floor(length(y))))
title('Noise-signal')
xlabel('Time [s]');
grid on
set(gcf, 'color', 'white');
%
%
L=fs/Br; %number of samples per symbol
%
% =================  Autocorrelation receiver (by Petrovich)
r = zeros(1,length(y));
for i=1:length(y),
    if i > C
        r(i) = y(i)*y(i - C);
    end
end
%
%
nfft=16384;
%w = window(@blackmanharris,nfft);
wind = window(@hamming,nfft);
%
[Pxx1,f] = pwelch(r,wind,nfft/2,nfft,fs);
Pxx1=Pxx1/max(abs(Pxx1));
%
%plotting PSD for r[n]
figure()
%
subplot(2,1,1);
plot(f,10*log10(Pxx1),'b')
%
title([{'Normalized Welch Power Spectral Density of r[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
os_x=[0:20:500];
set(gca,'xtick',os_x,'xgrid','on');
xlim([0 500]);
grid on
%
[Pxx2,f] = periodogram(r,[],[],fs);
Pxx2=Pxx2/max(abs(Pxx2));
%
subplot(2,1,2);
plot(f,Pxx2,'b')
title([{'Normalized Periodogram of r[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]');
os_x=[0:20:500];
xlim([0 500]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
%
r2 = r .^ 2;
%
wavwrite(r2(C+1:end),fs,16,'sequence_r2[n].wav');
%
[Perw,f] = pwelch(r2,wind,nfft/2,nfft,fs);
Perw=Perw/max(abs(Perw));
%
figure()
%
subplot(2,1,1);
plot(f,10*log10(Perw),'b')
%
title([{'Normalized Welch Power Spectral Density of r^2[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
os_x=[0:20:500];
set(gca,'xtick',os_x,'xgrid','on');
xlim([0 500]);
grid on
%
[Per,f] = periodogram(r2,[],[],fs);
Per=Per/max(abs(Per));
%
subplot(2,1,2);
plot(f,10*log10(Per),'b')
title([{'Normalized Periodogram of r^2[n]'}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]');
os_x=[0:20:500];
xlim([0 500]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
%
acf = abs(ifft(Perw)');
acf = acf ./ max(acf);
lags=0:1:length(acf)-1;
t=0:1/fs:(length(acf)-1)*(1/fs);
%
figure()
subplot(2,1,1)
plot(t,10*log10(acf))
title([{'Inverse FFT of pwelch( r^2[n] )'}])
xlabel('Time [s]')
ylabel('abs(ifft(pwelch(r^2[n]))');
xlim([0 0.05]);
grid on
%
subplot(2,1,2)
plot(lags,10*log10(acf))
title([{'Inverse FFT of pwelch( r^2[n] )'}])
xlabel('Samples [Sa]')
ylabel('abs(ifft(pwelch(r^2[n]))');
os_x=[0:50:400];
xlim([0 400]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
acf = autoCorr2(r2,0);
lags=0:1:length(acf)-1;
t=0:1/fs:(length(acf)-1)*(1/fs);
%
figure()
subplot(2,1,1)
plot(t,acf)
title([{'ACF using Matlab xcov( r^2[n] , maxlags, ''coeff'' )'}])
xlabel('Time [s]')
ylabel('ACF');
xlim([0 0.05]);
grid on
%
subplot(2,1,2)
plot(lags,acf)
title([{'ACF using Matlab xcov( r^2[n] , maxlags, ''coeff'' )'}])
xlabel('Lags [Sa]')
ylabel('ACF');
os_x=[0:50:400];
xlim([0 400]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
%
acf = real(ifft(fft(r2).*conj(fft(r2))));
acf = acf./max(abs(acf));
%
lags=0:1:length(acf)-1;
t=0:1/fs:(length(acf)-1)*(1/fs);
%
figure()
subplot(2,1,1)
plot(t,acf)
title([{'ACF estimate using ifft( fft(r^2[n]) * conj(fft(r^2[n])) )'}])
xlabel('Times [s]')
ylabel('ACF');
xlim([0 0.05]);
grid on
%
subplot(2,1,2)
plot(lags,acf)
title([{'ACF estimate using ifft( fft(r^2[n])  * conj(fft(r^2[n])) )'}])
xlabel('Lags [Sa]')
ylabel('ACF');
os_x=[0:50:400];
xlim([0 400]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
acf = real(ifft(log(abs(fft(r2)))));
lags=0:1:length(acf)-1;
t=0:1/fs:(length(acf)-1)*(1/fs);
%
figure()
subplot(2,1,1)
plot(t,acf)
title([{'ACF estimate using real( ifft( log( abs( fft( r2 )) ) ) ) ), i.e. rceps'}])
xlabel('Times [s]')
ylabel('ACF');
xlim([0 0.05]);
grid on
%
subplot(2,1,2)
plot(lags,acf)
title([{'ACF estimate using real( ifft( log( abs( fft( r2 )) ) ) ) ), i.e. rceps'}])
xlabel('Lags [Sa]')
ylabel('ACF');
os_x=[0:50:400];
xlim([0 400]);
set(gca,'xtick',os_x,'xgrid','on');
grid on
set(gcf, 'color', 'white')
%
%
%
acf=autoCorr(r,0);
%
figure();
t=0:1:length(acf)-1;
plot(t,acf)
ylim([-0.5 0.5]);
xlim([0 10000]);
xlabel('lags [Sa]');
ylabel('abs(ACF)');
title('Autocorrelation function of the noise-signal')
grid on
set(gcf, 'color', 'white');
%
%
figure()
t=(C):1:(C+500);
subplot(3,1,1);
plot(t,r(1,(C+1):(C+501)))
title([{'Sequence r[n] - 500 samples from n=C to n=C+499'}]);
xlim([(C) (C+500)]);
ylim([-1.2 1.2])
xlabel([{'samples [Sa]';''}])
grid on;
%
%
%
% averaging filtering
h = ones(L,1)/L;
mi = filter(h,1,r); % decision statistic
%
nn=length(mi)-1000;   %number of samples to display
subplot(3,1,2);
plot(2*C:1:2*C+nn, mi(1,2*C+1:2*C+nn+1));
title([{'Sequence {\mu}[{\itn}] - decision statistic waveform'}]);
xlim([2*C 2*C+nn])
xlabel(['Initial{ }' int2str(nn) '{ }samples [Sa]'])
grid on
set(gcf, 'color', 'white')
%
%removing outlayers
mi = mi(1,C+1:end);
%
%save decision statistic into WAVE file
indMax = find(abs(mi) == max(abs(mi)));
extrVal = mi(indMax(1));
if extrVal > 0,
    valMax = extrVal + 0.0025;
else
    valMax = extrVal - 0.0025;
end
%
minorm = mi ./ valMax;
%
subplot(3,1,3);
plot(2*C:1:2*C+nn, minorm(1,2*C+1:2*C+nn+1));
xlim([2*C 2*C+nn])
ylim([-1 1])
title([{'Normalized sequence {\mu}[{\itn}] - decision statistic waveform'}]);
xlabel(['Initial{ }' int2str(nn) '{ }samples [Sa]'])
grid on
%
%writting decision statistic waveform into WAVE file
wavwrite(minorm,fs,16,'noiseTelegram_decisionStatistic.wav');
%
%