% estimates half of the ACF (symmetry)
function rhalf2=autoCorr(s,maxlag)
%
M=length(s);
if maxlag==0 
    maxlag=M-1; 
end
% =========== ACF estimatator
r=xcov(s,maxlag,'coeff');
rhalf=r((maxlag+1):end);
rhalf2=rhalf;
