function noiseSignalAcfEstimator(fileName,xLim,yLim)
% fileName = noise-signal (WAVE file), here: 'noiseTelegram.wav'
% xLim = number of samples to display on ACF X axis 
% xLim = limitation of ACF amplitude
%
% for example:
% noiseSignalAcfEstimator('noiseTelegram.wav',5000,1)
clc;
close all;
%
[y,fs,bitsPerSample] = wavread(fileName);
y=y(:);
y=y';
%
figure()
t=0:1/fs:(length(y)-1)*(1/fs);
plot(t,y(1,1:floor(length(y))))
title('Noise-signal')
xlabel('Time [s]');
grid on
set(gcf, 'color', 'white');
%
acf=autoCorr(y,0);
%
figure();
t=0:1:length(acf)-1;
plot(t,abs(acf))
ylim([0 yLim]);
xlim([0 xLim]);
xlabel('lags [Sa]');
ylabel('abs(ACF)');
title('Autocorrelation function of the noise-signal')
grid on
set(gcf, 'color', 'white');
%
%