% estimates half of the ACF (symmetry)
function [rhalf]=autoCorr(s,maxlag)
%
M=length(s);
if maxlag==0 
    maxlag=M-1; 
end
% =========== PREPROCESSING
% converting into discrete-time analytic signal using Hilbert transform
u = hilbert(s);
% instant power of band-pass real signal
p = (abs(u)) .^ 2;
%
% simple approximator of the derivative, 
% i.e. digital filter H(z) = 1 - z^-2 
%
%{
dp = [0 0 zeros(1,length(p)-2)];
for i=3:length(p),
    dp(i)=(p(i)-p(i-2));
end
%}
dpTemp1 = p(1,1:length(p)-2);
dpTemp2 = p(1,3:length(p));
dp = [0 0 dpTemp2 - dpTemp1];
%
% =========== ACF estimatator
r=xcov(dp,maxlag,'coeff');
rhalf=r((maxlag+1):end);
%

