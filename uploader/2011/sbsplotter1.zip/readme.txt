sbsplotter-1
============

Update V1.3
===========
For update replace old "sbsplotter1.exe" with new one.

A major update, please read the lines below carefully

== Mode-S aircraft code
stored for the most distant airplane and saved as file sbsplotter1.hex on
program end (or by means below) and reloaded on program start
(or by means below)

== New subfolder for SBSplotter1 data files
A new subfolder "sbsplotter1" will be created below the Basestation folder. All
files that were stored in the Basestation folder and need to go to this folder
will be AUTOMATICALLY moved to the new folder on first program run.
The sbsplotter1.exe file remains in the Basestation folder!

== New STOP button
The old SAVE TO OUTFILE button is now cancelled and it is used to STOP the
data recording. This is useful when doing a preview of loaded or autosaved files.
See below on how to save files.

== The CLEAR button
was transferred to the new DATA | CLEAR menu

== New FILE menu
From this menu you can save files manually.
"Plot files" are the files that store the max distance information
for the tracks and level bands (actually 3 files: .max,
.dat and .hex. This is a lot, but it keeps downwards compatibility).
The default file (no date) is saved when you end SBSplotter1
and loaded when you open it. It can be overwritten or loaded from here, too.
You can also manually save a plot file that contains the DATE (YYYY-MM-DD) in its
filename now. This means you can save one extra file manually per day.
In reverse, from this menu you can load the default file at any time during
program run -or- a file with a DATE - or - a file with a DATE/TIME in its
filename at any time.

== New AUTOSAVE menu
From this menu you can start an automatic cycled file save for the plot
files or OUT files.
Remember OUT files CANNOT be reloaded to SBSplotter1, but only be displayed in
Basestation!
You can choose between a 1, 6, 12 and 24 hrs interval to save the files.
The interval starts when the START button is hit.
Check "CLEAR DATA ON AUTOSAVE" to restart a plotting session after a file
was saved.
Files will be stored in the Basestation/sbsplotter1 folder.
Files contain the DATE/TIME of storage (YYYY-MM-DD.HH-MI) in its filename.
Plot files can be reloaded from the FILE menu "Load file with date" and viewed
in SBSplotter1.

It sounds more complicated than it actually is. Just try ;-)

Remember: all times are LOCAL, all data are delayed by 5 minutes

Final release for 2006
Happy new year 2007!!

Update V1.2
===========
For update replace old sbsplotter1.exe with new one.
New function:
A Mode-S ID blacklist is checked against messages processed. Airplanes on
the blacklist will not be processed.
The blacklist will be created on program run in your Basestation folder. It
is named "sbsplotter1.blacklist.txt". You can open end edit and save it during
program run, there are more instructions in it. Please use notepad, NO WORD.
An edited blacklist is reloaded to SBSplotter1 after 60 seconds latest.

Update V1.1  (27 DEC 06)
===========
For update replace old sbsplotter1.exe with new one.
New functions:
- Range filter 180-450 NM
- Excessive range log file ("sbsplotter1.log")
- Preview radar scope with adjustable range 60-360 NM
- Minimize application to systray (click icon to resize)
- New button to clear data during program run

When comparing the Basestation screen with the Preview screen, please
be aware: ALL PLOT DATA ARE 5 MINUTES DELAYED

================================================================================

- Place sbsplotter1.exe to your Basestation folder.
- Your home position must be correctly saved in basestation.ini. If not,
you have to enter it into the LAT / LONG field exactly as it is present in
Basestation!
- Start sbsplotter1.exe and press START and let it run for a couple of
hours or days
- Press SAVE TO OUTFILE and a file "sbsplotter.out" will be added to the
basestation/outlines folder
- enable outlines layers 25-29 in Basestation (if not done so)
- Reload Basestation outlines and view your radar plot

Radar plots are stored in five layers for certain flightlevel bands
Layer
25      GND to FL99
26      FL100 to FL199
27      FL200 to FL299
28      at or above FL300
29      all levels

The radar plot line shows the maximum distance observed within the
relevant flightlevel band.

Distance and Tracks are calculated with the Great Circle method.

After saving the OUT file all data are kept and recording continues.

Radar plots are saved on program end to files "sbsplotter1.dat" and
"sbsplotter1.max". These can be optionally reloaded on next program start.

"sbsplotter1.log" can be opened and edited with Notepad.

Enjoy it.
Happy xmas!