function noiseSignalModulator(Br,fs,C_Sa,yLim)
% Br - Baud rate [Hz]
% fs - sampling frequency [Hz]
% C_Sa - delay in samples [Sa]
% yLim - variable describing limitation of Y axis for ACF graph
clc;
close all;
%
L=fs/Br; % number of samples per symbol
%
% txt message to transmit
txt1=['RYRYRYRYRY'];
%txt2 = 'Conversation should be pleasant without scurrility, witty without affectation, free without indecency, learned without conceitedness, novel without falsehood. William Shakespeare.';
txt2 = 'Tis but thy name that is my enemy: Thou art thyself, though not a Montague. Whats Montague? It is nor hand nor foot, Nor arm nor face, nor any other part Belonging to a man. O be some other name! Whats in a name? That which we call a rose By any other word would smell as sweet; So Romeo would, were he not Romeo calld, Retain that dear perfection which he owes Without that title. Romeo, doff thy name, and for thy name, which is no part of thee,Take all myself.';
txt = [txt1 txt2];
messBin = [];
for i=1:length(txt),
    binWord = de2bi(double(txt(i)),8); % right most significant bit is default
    %asciiChar = char(bi2de(binWord,'left-msb'));
    messBin = horzcat(messBin,binWord);
    %pause
end
bprim = messBin;
%
%save the binary message into the txt file (for checking purpose)
txtFileName='binMessage_8_rmsb.txt'; % rmsb = right most significant bit
fid=fopen(txtFileName,'wt');
fprintf(fid,'%d',messBin);
fclose(fid);
%
%zeroinserting
b=zeros(length(bprim)*L,1);
b(1:L:length(b))=bprim;
%
%interopolation filtering (zero order hold (ZOH))
h=ones(L,1);
bl=filter(h,1,b);
bl=bl';
%
nOfSymb=10; % number of initial symbols
%
figure();
stairs(bl(1,1:nOfSymb*L),'LineWidth',2)
title([{['Binary message b[n] (Br ={ }' int2str(Br) '{ }Bd => T_b ={ }' ...
    int2str(fs) '/' int2str(Br) '{ }={ }' int2str(L) '{ }Sa)']}]);
xlabel([{['Initial{ }' int2str(nOfSymb) '{ }interpolated symbols - ' ...
    int2str(nOfSymb) '*' int2str(L) '{ }samples'];''}]);
os_x=[0:L/2:nOfSymb*L];
set(gca,'xtick',os_x,'xgrid','on');
ylim([0 1.2])
grid on;
set(gcf, 'color', 'white');
%
%
% Noise generator (normal random numbers)
%
rand('seed',777);
%
wi=[0 0 randn(1,length(bl)-2)];
%
wf=[0 0 zeros(1,length(bl)-2)];
%
nOfFilterInCascade = 4;
%
nfft=2048;
wind = window(@blackmanharris,nfft);
%
figure()
% cascade of noise band narrowing filters 
for k=1:nOfFilterInCascade,
    for i=3:length(wf),
        wf(i)=(wi(i)-wi(i-2))/2;
    end
    wi = wf;
    %
    [Pxx,f] = pwelch(wf,wind,nfft/2,nfft,fs);
    Pxx=Pxx/max(abs(Pxx));
    %
    % linear scale
    subplot(nOfFilterInCascade,2,2*k-1);
    plot(f,Pxx,'b')
    %
    title([{['Welch Power Spectral Density of band-narrowed noise w_' int2str(k) '[n]']}])
    xlabel([{'F [Hz]';''}])
    ylabel('PSD [W/Hz]')
    os_x=[0:300:3900];
    set(gca,'xtick',os_x,'xgrid','on');
    grid on
    % dB scale
    subplot(nOfFilterInCascade,2,2*k);
    plot(f,10*log10(Pxx),'b')
    %
    title([{['Normalized Welch Power Spectral Density of band-narrowed noise w_' int2str(k) '[n]']}])
    xlabel('F [Hz]')
    ylabel('PSD [dBc/Hz]')
    os_x=[0:300:3900];
    set(gca,'xtick',os_x,'xgrid','on');
    ylim([-60 0])
    grid on
end
set(gcf, 'color', 'white')
%
%
%================ NOISE KEYING (noise manipulator)
%
wc = sqrt(2)*wf(1:C_Sa);% to avoid rapid signal power jump at the time instant
                        % n = C_Sa
%
w0=[wc zeros(1,length(wf)-C_Sa)];
w1=[wc zeros(1,length(wf)-C_Sa)];
%
for i=(C_Sa+1):length(wf),
    w0(i)= wf(i) + wf(i-C_Sa);
    w1(i)= wf(i) - wf(i-C_Sa);
end
%
s=zeros(1,length(bl));
%
for i=1:length(bl),
    if (bl(i) == 0),
        s(i)=w0(i);
    else
        s(i)=w1(i);
    end
end
%
figure();
plot(s(1,1:10*L),'b')
title([{'';'Maniputated noise-signal - s[n] sequence'}]);
xlabel(['Initial 10*' int2str(L) '{ }samples [Sa]']);
set(gcf, 'color', 'white')
grid on
%
%
% ========= Welch Power Spectral Density of manipulated noise-signal
%
nfft=2048;
wind = window(@blackmanharris,nfft);
%
[Pxx,f] = pwelch(s,wind,nfft/2,nfft,fs);
Pxx=Pxx/max(abs(Pxx));
%
% linear scale
figure()
subplot(2,2,1);
plot(f,Pxx,'b')
%
title([{['Welch Power Spectral Density of manipulated noise-signal s[n]']}])
xlabel([{'F [Hz]';''}])
ylabel('PSD [W/Hz]')
os_x=[0:300:3900];
set(gca,'xtick',os_x,'xgrid','on');
grid on
%
% dB scale
subplot(2,2,2);
plot(f,10*log10(Pxx),'b')
%
title([{['Normalized Welch Power Spectral Density of manipulated noise-signal s[n]']}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
os_x=[0:300:3900];
set(gca,'xtick',os_x,'xgrid','on');
ylim([-60 0])
grid on
%
%
s = awgn(s,20);
%
[Pxx,f] = pwelch(s,wind,nfft/2,nfft,fs);
Pxx=Pxx/max(abs(Pxx));
%
% linear scale
subplot(2,2,3);
plot(f,Pxx,'b')
%
title([{['Welch Power Spectral Density of manipulated noise-signal s[n] with AWGN 20dB added']}])
xlabel([{'F [Hz]';''}])
ylabel('PSD [W/Hz]')
os_x=[0:300:3900];
set(gca,'xtick',os_x,'xgrid','on');
grid on
%
% dB scale
subplot(2,2,4);
plot(f,10*log10(Pxx),'b')
%
title([{['Normalized Welch Power Spectral Density of manipulated noise-signal s[n] with AWGN 20dB added']}])
xlabel('F [Hz]')
ylabel('PSD [dBc/Hz]')
os_x=[0:300:3900];
set(gca,'xtick',os_x,'xgrid','on');
ylim([-60 0])
grid on
set(gcf, 'color', 'white')
%
%
%%================ Autocorrelation function (ACF) of noise-signal
% 
figure()
acf=autoCorr(s,0);
t=0:1/fs:(length(s)-1)*(1/fs);
%
subplot(2,1,1);
plot(t,acf);
grid on;
ylim([-yLim yLim])
xlim([0 1])
xlabel('time [s]');
ylabel('ACF');
%%{
title([{'Autocorrelation Function of the manipulated noise-signal';...
        strcat('fs={ }', int2str(fs), '{ }Hz;{ }Br={ }',...
        int2str(Br),'{ }Bd;{ }C={ }',int2str(C_Sa),'{ }[Sa]')}])
%%}
%title([{'Autocorrelation Function of the manipulated noise-signal'}]);
set(gcf, 'color', 'white');
%
acf=abs(acf);
%
subplot(2,1,2);
plot(0:1:length(acf)-1, acf)
ylim([0 yLim])
xlim([0 10000])
grid on;
xlabel('lags [Sa]');
ylabel('abs(ACF)');
%%{
title([{'Autocorrelation Function of the manipulated noise-signal';...
        strcat('fs={ }',int2str(fs), '{ }Hz;{ }Br={ }',...
        int2str(Br),'{ }Bd;{ }C={ }',int2str(C_Sa),'{ }[Sa]')}])
%%}
%title([{'Autocorrelation Function of the manipulated noise-signal'}]);
set(gcf, 'color', 'white')
%
%
%======================================
% normalization to avoid data clipping while writing into WAVE file
%{
sHigh = max(s) - eps;
sLow = min(s) + eps;
snorm = ((2*s - (sHigh + sLow))/(sHigh - sLow));
%}
%
indMax = find(abs(s) == max(abs(s)));
extrVal = s(indMax(1));
if extrVal > 0,
    valMax = extrVal + 0.0025;
else
    valMax = extrVal - 0.0025;
end
%
snorm = s ./ abs(valMax);
%
figure()
subplot(2,1,1);
plot(t,s);
xlabel([{'time [s]';''}]);
title('Whole noise-signal');
grid on;
subplot(2,1,2);
plot(t,snorm);
xlabel('time [s]');
title('Whole normalized noise-signal');
set(gcf, 'color', 'white')
grid on;
%
%writting data into WAVE file
wavwrite(snorm,fs,16,'noiseTelegram.wav')
%
%}
end