/*****************************************************
This program was produced by the
CodeWizardAVR V1.25.3 Standard
Automatic Program Generator
� Copyright 1998-2007 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 07.11.2011
Author  : Dmitry Eljuseev, RA1AHC. dmitryelj@gmail.com                            


Chip type           : ATtiny13
Clock frequency     : 9,600000 MHz
Memory model        : Tiny
External SRAM size  : 0
Data Stack size     : 16
*****************************************************/

#include <tiny13.h>     
#include <delay.h> 

// Port out:
#define POUT   0  
// Port audio (do not change! hardware pwm)
#define PAUDIO 1
// Port LED:
#define PLED   2   

#define REPEAT 3

// Morze length
#define L_DOT    80
#define L_LINE   3*L_DOT
#define S_PAUSE  L_DOT
#define C_PAUSE  3*L_DOT  

#define TONE_ON    TCCR0A=0x23
#define TONE_OFF   TCCR0A=0x03

const unsigned char phrase[] = "CQ CQ DE BEACON 1/2W FROM SPB RU 60N 30E SEND REPORTS TO BEACONSPB  GMAIL COM.";

#define REPEAT_DL 12000

// Declare your global variables here
// 0 - "."
// 1 - "-"   
// 2 - pause        
// 3 - long pause        
// 5 - null
#define SYM_LEN 5
#define mA 0,1,5,5,5
#define mB 1,0,0,0,5
#define mC 1,0,1,0,5
#define mD 1,0,0,5,5
#define mE 0,5,5,5,5
#define mF 0,0,1,0,5
#define mG 1,1,0,5,5
#define mH 0,0,0,0,5
#define mI 0,0,5,5,5
#define mJ 0,1,1,1,5
#define mK 1,0,1,5,5
#define mL 0,1,0,0,5
#define mM 1,1,5,5,5
#define mN 1,0,5,5,5
#define mO 1,1,1,5,5
#define mP 0,1,1,0,5
#define mQ 1,1,0,1,5
#define mR 0,1,0,5,5
#define mS 0,0,0,5,5
#define mT 1,5,5,5,5
#define mU 0,0,1,5,5
#define mV 0,0,0,1,5
#define mW 0,1,1,5,5
#define mX 1,0,0,1,5
#define mY 1,0,1,1,5
#define mZ 1,1,0,0,5
#define m0 1,1,1,1,1
#define m1 0,1,1,1,1
#define m2 0,0,1,1,1
#define m3 0,0,0,1,1
#define m4 0,0,0,0,1
#define m5 0,0,0,0,0
#define m6 1,0,0,0,0
#define m7 1,1,0,0,0
#define m8 1,1,1,0,0
#define m9 1,1,1,1,0
#define m_ 2,2,2,5,5       
#define mSl 1,0,0,1,0

const unsigned char symbols[] = { 
                                        mSl, m0, m1, m2, m3, m4, m5, m6, m7, m8, m9,    // '/',0,1-9
                                        m_, m_, m_, m_, m_, m_, m_,                     // :;<=>?@
                                        mA, mB, mC, mD, mE, mF, mG, mH, mI, mJ, mK, mL, mM, mN, mO, mP, mQ, mR, mS, mT, mU, mV, mW, mX, mY, mZ 
                                };

void morze_out(flash unsigned char *pData)
{                       
        unsigned char p, p1;
        for(p=0; p<128; p++)
        {                       
                unsigned char symb = pData[p];
                if (symb == '.') break;
                if (symb == '*') // �������� 1 ������� 
                { 
                    PORTB.POUT = 1; 
                    TONE_ON;
                    delay_ms(1000); 
                    PORTB.POUT = 0; 
                    TONE_OFF;
                    delay_ms(S_PAUSE); 
                    continue; 
                }                
                                       
                if (symb == ' ') symb = '='; // ��� ������� ���� � ���� �������
                if (symb >= '/' && symb <= 'Z')
                {                
                        unsigned int symb_code  = symb - '/';
                        unsigned int symb_index = SYM_LEN*symb_code;    
                        if (symb_index >= sizeof(symbols)) continue;  
                                        
                        for(p1=0; p1<SYM_LEN; p1++)
                        {
                               if (symbols[symb_index + p1] == 0) // "."
                               {                     
                                       PORTB.POUT = 1; 
                                       TONE_ON;
                                       delay_ms(L_DOT);
                                       PORTB.POUT = 0;   
                                       TONE_OFF;
                                       delay_ms(S_PAUSE);
                               } else
                               if (symbols[symb_index + p1] == 1) // "-"
                               {                     
                                       PORTB.POUT = 1;  
                                       TONE_ON;
                                       delay_ms(L_LINE);
                                       PORTB.POUT = 0;   
                                       TONE_OFF;
                                       delay_ms(S_PAUSE);
                               } else
                               if (symbols[symb_index + p1] == 2) // "pause"
                               {                     
                                       delay_ms(S_PAUSE);
                               } 
                        }                                                          
                        
                        delay_ms(C_PAUSE);
                } 
        }
}

void main(void)
{
        // Input/Output Ports initialization
        // Port B initialization
        // Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
        // State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
        PORTB=0x00;
        DDRB=0x3F;
        
        // Timer/Counter 0 initialization
        // Clock source: System Clock
        // Clock value: 75.000 kHz
        // Mode: Fast PWM top=FFh
        // OC0A output: Disconnected
        // OC0B output: Non-Inverted PWM
        TCCR0A=0x23;//0x03;
        TCCR0B=0x03;
        TCNT0=0x00;
        OCR0A=0x00;
        OCR0B=0x80;
        
        // External Interrupt(s) initialization
        // INT0: Off
        // Interrupt on any change on pins PCINT0-5: Off
        GIMSK=0x00;
        MCUCR=0x00;
        
        // Timer/Counter 0 Interrupt(s) initialization
        TIMSK0=0x00;
        
        // Analog Comparator initialization
        // Analog Comparator: Off
        ACSR=0x80;
        ADCSRB=0x00;  
        
        TONE_OFF;
        
        while (1)
        {                         
                unsigned char p;
                for(p=0; p<REPEAT; p++)
                {
                        morze_out(phrase);
        
                        PORTB.PLED = 1;
                        delay_ms(1500);
                        PORTB.PLED = 0;
                }
                
                delay_ms(REPEAT_DL);             
        
        };
}
