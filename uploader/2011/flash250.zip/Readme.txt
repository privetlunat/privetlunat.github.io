Run Flash250.bat
